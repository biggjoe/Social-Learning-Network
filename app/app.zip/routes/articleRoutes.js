var zapp = angular.module('article.router', []);

zapp.config( ['$stateProvider', 
  '$locationProvider', 
  '$urlRouterProvider',
  function(
    $stateProvider, 
    $locationProvider, 
    $urlRouterProvider) {
    console.log($stateProvider)
//$locationProvider.html5Mode(true);
$locationProvider.html5Mode({ enabled: true, requireBase: false, rewriteLinks: false });
//$urlRouterProvider.when('/', '/profile/details');
$urlRouterProvider.when('/article', '/article/:url');
$stateProvider
.state('home',{
 url: '/article',
 views: {
  'menuContent':{
    templateUrl: 'templates/public/article.html'
  }
 }
 })


.state('home.details',{
 url: '/:url',
 views: {
  'idasher':{
    templateUrl: 'templates/public/article/article-details.html'
  },
  params:{pageTitle:'Article'}
 }
 })




//let newUrl = '/profile/'+$rootScope.username;
let newUrl = '/home';

$urlRouterProvider.otherwise(newUrl);

}]);
